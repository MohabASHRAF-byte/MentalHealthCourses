namespace MentalHealthcare.Application.SystemUsers.Commands.Refresh;

public class RefreshResponse
{
    public string AccessToken { get; set; }
    public string RefreshToken { get; set; }
}