namespace MentalHealthcare.Application.SystemUsers;

public class UserDto
{
    public string UserName { get; set; } = default!;
    public string FirstName { get; set; } = default!;
    public string LastName { get; set; } = default!;
}