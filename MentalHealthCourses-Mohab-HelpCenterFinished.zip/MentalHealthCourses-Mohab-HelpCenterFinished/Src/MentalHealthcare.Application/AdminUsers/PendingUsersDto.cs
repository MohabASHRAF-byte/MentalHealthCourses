namespace MentalHealthcare.Application.AdminUsers;

public class PendingUsersDto
{
    public string Email { get; set; } = default!;
}