namespace MentalHealthcare.Application.BunnyServices.Dtos;

public class DeleteFileResponse
{
    public bool IsSuccessful { get; set; }
    public string? Message { get; set; } 
}