namespace MentalHealthcare.Application.Courses.Commands.Create;

public class CreateCourseCommandResponse
{
    public int CourseId { get; set; }
}