// using MediatR;
//
// namespace MentalHealthcare.Application.TermsAndConditions.Commands.Update;
//
// public class UpdateTermCommand:IRequest
// {
//     public Domain.Entities.TermsAndConditions term { get; set; }
// }