namespace MentalHealthcare.Domain.Repositories;

public interface IVideoStreamService
{
    
}