namespace MentalHealthcare.Domain.Dtos;

public class PodCastDto
{
    public string Url { get; set; }
}