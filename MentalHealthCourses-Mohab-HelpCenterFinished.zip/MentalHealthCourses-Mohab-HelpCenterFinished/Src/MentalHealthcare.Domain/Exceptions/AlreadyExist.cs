namespace MentalHealthcare.Domain.Exceptions;

public class AlreadyExist(string msg):Exception(msg)
{
    
}