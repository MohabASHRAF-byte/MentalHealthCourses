namespace MentalHealthcare.Domain.Exceptions;

public class ForBidenException(string msg) : Exception(msg);