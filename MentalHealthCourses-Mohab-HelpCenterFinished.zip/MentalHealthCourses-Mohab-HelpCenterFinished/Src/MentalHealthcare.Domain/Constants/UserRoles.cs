namespace MentalHealthcare.Domain.Constants;

public enum UserRoles
{
    Admin = 0,
    User = 1,
}