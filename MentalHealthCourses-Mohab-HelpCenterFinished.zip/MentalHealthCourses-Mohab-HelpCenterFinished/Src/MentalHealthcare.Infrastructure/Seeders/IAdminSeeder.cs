namespace MentalHealthcare.Infrastructure.Seeders;

public interface IAdminSeeder
{
    public Task seed();
}